import React from "react";
import './counter.css'
import './counterjs'
const Counter = () => {
  return (
    <section class="counters">
      <div class="container">
        <div>
          <i class="fab fa-youtube fa-4x"></i>
          <div class="counter" data-target="60000">
            0
          </div>
          <h3>Subscribers</h3>
        </div>
        <div>
          <i class="fab fa-twitter fa-4x"></i>
          <div class="counter" data-target="15000">
            0
          </div>
          <h3>Followers</h3>
        </div>
        <div>
          <i class="fab fa-facebook fa-4x"></i>
          <div class="counter" data-target="9000">
            0
          </div>
          <h3>Likes</h3>
        </div>
        <div>
          <i class="fab fa-linkedin fa-4x"></i>
          <div class="counter" data-target="5000">
            0
          </div>
          <h3>Connections</h3>
        </div>
      </div>
    </section>
  );
};

export default Counter;
