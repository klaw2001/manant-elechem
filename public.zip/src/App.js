import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import "./App.css";
import Topbar from "./components/Header/Topbar";
import Navbar from "./components/Header/NavbarX";
import Home from "./pages/Home";

function App() {
  return (
    <div className="">
      <Router>
        <header className="position-relative">
          <Topbar />
          <Navbar />
        </header>
        <Routes>
          <Route path="/" element={<Home />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
